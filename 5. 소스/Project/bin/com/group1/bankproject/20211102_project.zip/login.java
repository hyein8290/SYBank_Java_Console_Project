package com.group1.bankproject;

import java.io.IOException;
import java.util.Scanner;

import com.group1.bankproject.steven.userLogin;

public class login {
	
	private static Scanner scan;
	static { scan = new Scanner(System.in); }
	
	public static void main(String[] args) throws IOException {

		System.out.println();
		
		boolean loop = true;
		
		while (loop) { 
			
			menu();	
			
			Scanner scan = new Scanner(System.in);
			System.out.println();
			System.out.print("선택(숫자) : ");
			String sel = scan.nextLine();
		
			try {
				if (sel.equals("1")) {
					com.group1.bankproject.userLogin.login();;
				} else if (sel.equals("2")) {
					System.out.println();
					managerLogin.Login();
				} else if (sel.equals("3")) {
					join.userjoin();
				} else if (sel.equals("4")) {
					findID.id();
				} else if (sel.equals("5")) {
					findPW.pw();
				} else if (sel.equals("6")) {
					System.out.println("쌍용은행을 이용해주셔서 감사합니다.");
					System.exit(0);
				} else {
					loop = false;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		}//while 
		
		System.out.println();
		pause("1-6사이의 숫자를 입력해주세요.");
		login.main(args);
		
	}//main
	
	private static void pause (String msg) {
		System.out.println(msg);
		System.out.println("계속 진행하시려면 엔터키를 누르세요.");
		scan.nextLine();
	}//pause + 디자인 변경 맟춰서 +-하기 

	private static void menu() {
		
		System.out.println("=====================");
		System.out.println("        로그인");
		System.out.println("---------------------");
		System.out.println(" 1. 회원 로그인 ");
		System.out.println(" 2. 관리자 로그인 ");
		System.out.println(" 3. 회원가입 ");
		System.out.println(" 4. 아이디 찾기 ");
		System.out.println(" 5. 비밀번호 찾기 ");
		System.out.println(" 6. 종료 ");
		System.out.println("=====================");
		
	}//menu

}//login.class
