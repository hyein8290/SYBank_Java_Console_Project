package com.group1.bankproject;

import java.util.Calendar;

public class UserSavingData {
	
	private int num;
	   private String savingAccount;
	   private int savingProductNum;
	   //월 납입금액, 계좌 총금액
	   private int perMonth;
	   private int savingAccoutSum;
	   private Calendar joinDate;
	   
	   public UserSavingData(int num, String savingAccount, int savingProductNum, int perMonth, int savingAccountSum, Calendar joinDate) {
	      this.num = num;
	      this.savingAccount = savingAccount;
	      this.savingProductNum = savingProductNum;
	      this.perMonth = perMonth;
	      this.savingAccoutSum = savingAccountSum;
	      this.joinDate = joinDate;
	            
	   }

	   public int getNum() {
	      return num;
	   }

	   public void setNum(int num) {
	      this.num = num;
	   }

	   public String getSavingAccount() {
	      return savingAccount;
	   }

	   public void setSavingAccount(String savingAccount) {
	      this.savingAccount = savingAccount;
	   }

	   public int getSavingProductNum() {
	      return savingProductNum;
	   }

	   public void setSavingProductNum(int savingProductNum) {
	      this.savingProductNum = savingProductNum;
	   }

	   
	   
	   public int getPerMonth() {
	      return perMonth;
	   }

	   public void setPerMonth(int perMonth) {
	      this.perMonth = perMonth;
	   }

	   public int getSavingAccoutSum() {
	      return savingAccoutSum;
	   }

	   public void setSavingAccoutSum(int savingAccoutSum) {
	      this.savingAccoutSum = savingAccoutSum;
	   }

	   public Calendar getJoinDate() {
	      return joinDate;
	   }

	   public void setJoinDate(Calendar joinDate) {
	      this.joinDate = joinDate;
	   }

	   @Override
	   public String toString() {
	      return String.format(
	            "UserSavingData [num=%s, savingAccount=%s, savingProductNum=%s, perMonth=%s, savingAccoutSum=%s, joinDate=%s]",
	            num, savingAccount, savingProductNum, perMonth, savingAccoutSum, joinDate);
	   }

}
