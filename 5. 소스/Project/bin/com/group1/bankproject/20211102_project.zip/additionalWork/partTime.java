package com.group1.bankproject.additionalWork;

public class partTime {
	
	private int hourPay;
	private int albaTime;
	private int weekday;

	public partTime() {
		
	}

	public partTime(int hourPay, int albaTime, int weekday) {
		this.hourPay = hourPay;
		this.albaTime = albaTime;
		this.weekday = weekday;
	}
	
	public int getHourPay() {
		return hourPay;
	}
	public void setHourPay(int hourPay) {
		if (hourPay <0) {
			return;
		}
		this.hourPay = hourPay;
	}
	public int getAlbaTime() {
		return albaTime;
	}
	public void setAlbaTime(int albaTime) {
		if (albaTime <0 || albaTime > 24) {
			return;
		}
		this.albaTime = albaTime;
	}
	public int getWeekday() {
		return weekday;
	}
	public void setWeekday(int weekday) {
		if (weekday < 0 || weekday > 7) {
			return;
		}
		this.weekday = weekday;
	}
	
	public void calculate() {
		
		System.out.printf(	  "시급 \t\t\t: %,d\r\n"
							+ "일일 근로시간\t\t: %,d\r\n"
							+ "총 근로시간\t\t: %,d\r\n"
							+ "일급\t\t\t: %,d\r\n"
							+ "주급\t\t\t: %,d\r\n"
							+ "월급 \t\t\t: %,d\r\n"
							,this.hourPay
							,this.albaTime
							,this.weekday * this.albaTime
							,this.hourPay * this.albaTime
							,this.hourPay * this.albaTime * this.weekday
							,(this.hourPay * this.albaTime * this.weekday * 4)
								+ (this.hourPay * this.albaTime * 2)
																			);
		
	}
	
	@Override
	public String toString() {
		return String.format("partTime [hourPay=%s, albaTime=%s, weekday=%s]", hourPay, albaTime, weekday);
	}
	
	
	
	
}
