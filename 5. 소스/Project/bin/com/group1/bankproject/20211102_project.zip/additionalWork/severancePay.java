package com.group1.bankproject.additionalWork;

public class severancePay {
	
	private int thisMonth;
	private int lastMonth;
	private int twoMonthAgo;
	
	public severancePay() {
		
	}

	public severancePay(int thisMonth, int lastMonth, int twoMonthAgo) {
		this.thisMonth = thisMonth;
		this.lastMonth = lastMonth;
		this.twoMonthAgo = twoMonthAgo;
	}
	
	
	public int getThisMonth() {
		return thisMonth;
	}

	public void setThisMonth(int thisMonth) {
		this.thisMonth = thisMonth;
	}

	public int getLastMonth() {
		return lastMonth;
	}

	public void setLastMonth(int lastMonth) {
		this.lastMonth = lastMonth;
	}

	public int getTwoMonthAgo() {
		return twoMonthAgo;
	}

	public void setTwoMonthAgo(int twoMonthAgo) {
		this.twoMonthAgo = twoMonthAgo;
	}

	@Override
	public String toString() {
		return String.format("severancePay [thisMonth=%s, lastMonth=%s, twoMonthAgo=%s]", thisMonth, lastMonth,
				twoMonthAgo);
	}
	
	public void calculate() {
		System.out.printf(	"예상 퇴직금은 %,d원입니다.\r\n"
							,(this.thisMonth + this.lastMonth + this.twoMonthAgo)/3);
	}
	
	
	
	
	
	
	
}
