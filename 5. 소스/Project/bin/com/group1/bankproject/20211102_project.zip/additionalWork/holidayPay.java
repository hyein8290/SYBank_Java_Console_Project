package com.group1.bankproject.additionalWork;

public class holidayPay {
	
	private int hourPay;
	private int albaTime;
	private int weekday;
	
	public holidayPay() {
		
	}

	public holidayPay(int hourPay, int albaTime, int weekday) {
		this.hourPay = hourPay;
		this.albaTime = albaTime;
		this.weekday = weekday;
	}
	
	public int getHourPay() {
		return hourPay;
	}
	public void setHourPay(int hourPay) {
		if (hourPay <0) {
			return;
		}
		this.hourPay = hourPay;
	}
	public int getAlbaTime() {
		return albaTime;
	}
	public void setAlbaTime(int albaTime) {
		if (albaTime <0 || albaTime > 24) {
			return;
		}
		this.albaTime = albaTime;
	}
	public int getWeekday() {
		return weekday;
	}
	public void setWeekday(int weekday) {
		if (weekday < 0 || weekday > 7) {
			return;
		}
		this.weekday = weekday;
	}
	
	@Override
	public String toString() {
		return String.format("holidayPay [hourPay=%s, albaTime=%s, weekday=%s]", hourPay, albaTime, weekday);
	}
	
	public void calculate() {
		if (this.albaTime * this.weekday < 15) {
			System.out.println("주휴수당 조건이 충족되지 않았습니다.");
		} else {
			System.out.printf(	  "주휴수당 : %,d\r\n"
								+ "주휴수당 포함 일급 : %,d\r\n"
								,this.hourPay * this.albaTime
								,((this.hourPay * this.albaTime * this.weekday) + (this.hourPay * this.albaTime))/this.weekday
									);
		}
	}
	
	
	
}
