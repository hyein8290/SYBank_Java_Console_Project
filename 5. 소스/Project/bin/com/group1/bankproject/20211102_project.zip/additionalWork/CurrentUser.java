package com.group1.bankproject.additionalWork;

import java.util.ArrayList;

public class CurrentUser {
	
	private static int num;
	private static String name;
	private static int debt;
	private static String password;
	private static String jumin;
	private static ArrayList<String> accountList = new ArrayList<String>();
	
	public CurrentUser() {
		
	}

	public static String getJumin() {
		return jumin;
	}

	public static void setJumin(String jumin) {
		CurrentUser.jumin = jumin;
	}
	
	public static String getPassword() {
		return password;
	}
	
	public static void setPassword(String password) {
		CurrentUser.password = password;
	}
	
	public static int getNum() {
		return num;
	}
	
	public static void setNum(int num) {
		CurrentUser.num = num;
	}
	
	public static String getName() {
		return name;
	}
	
	public static void setName(String name) {
		CurrentUser.name = name;
	}

	public static int getDebt() {
		return debt;
	}

	public static void setDebt(int debt) {
		CurrentUser.debt = debt;
	}

	public static ArrayList<String> getAccountList() {
		return accountList;
	}

	public static void setAccountList(String accountList) {
		CurrentUser.accountList.add(accountList);
	}
	
	
	
	
}
