package com.group1.bankproject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class findPW {
   
   private static Scanner scan;
   static { scan = new Scanner(System.in); }
   
   public static void pw() throws IOException {
      
      String id="", jumin="";
      boolean check = true;
      
      System.out.println();
      System.out.println();
      header("5. 비밀번호 찾기");
      System.out.println();
      
      while (check) {
         System.out.print("아이디 (4~16자 이내) : ");
         id = scan.nextLine();
         if (userIDCheck(id)) { continue;} break; }
      while (check) {
         System.out.print("주민등록번호 (13자 이내) : ");
         jumin = scan.nextLine();
         if (userjuminCheck(jumin)) { continue;} break; }

      BufferedReader reader = new BufferedReader(new FileReader(MyPath.USERDATA));
      String line = null;
      
      boolean flag = false;
         
      while ((line = reader.readLine()) != null) {
         
         String[] temp = line.split(",");
      
         if (id.equals(line.split(",")[1]) && jumin.equals(line.split(",")[4])) {
            flag = true;
            break;
         } 
      }
      
      if (flag) {
         pause("회원님의 비밀번호는 " + line.split(",")[2] + "입니다.");
         login.main(null);
      } else {
         pause("!비밀번호 찾기 실패 : 아이디와 주민등록번호를 다시 입력해주세요.");
      }
      
   }//id
   
   private static boolean userjuminCheck(String jumin) {
      
      String regex = "^[0-9]{13}$";
      Pattern p = Pattern.compile(regex);
      Matcher m = p.matcher(jumin);

      if (!m.find()) {
         pause("주민등록번호는 숫자 13자리만 입력 가능합니다.");
         return true;
      } 
      return false;
      
   }//juminCheck
   
   private static boolean userIDCheck(String id) {
      
//      for (User user : users) {
//         if (user.getId().equals(id)) {
//            pause("중복된 아이디 입니다.");
//            return true;
//         }
//      }//userIDCheck
      
   if (id.length() < 4 || id.length() > 16) {
      pause("아이디는 4 ~ 16자로 입력해주세요.");
      return true;
   }
   
   for (int i = 0; i < id.length(); i++) {
      int ch = id.charAt(i); // "a" -> 'a'
      if (!(ch >= '0' && ch <= '9') && !(ch >= 'a' && ch <= 'z') && !(id.equals("_"))) {
         pause("영어 소문자, 숫자만 입력 가능합니다.");
         return true;
      }
   }
      
   return false;
   
}//IDCheck
   
   private static void header(String title) {
      System.out.printf("[%s]\r\n", title);
   }//header + 디자인 변경 맟춰서 +-하기 
   
   private static void pause(String msg) {
      System.out.println(msg);
      System.out.println("계속 진행하시려면 엔터키를 누르세요.");
      scan.nextLine();
   }//pause + 디자인 변경 맟춰서 +-하기 
   
}//findPW.class