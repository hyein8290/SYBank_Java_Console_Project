package com.group1.bankproject;

public class MyPath {
	
	public final static String MYPATH 
	= "/Users/songseonghyeon/eclipse-workspace/JavaTest/src/com/group1/bankproject/data/";
	
	public final static String FUNDPRODUCT
	= MYPATH + "펀드상품.csv";
	
	public final static String MANAGER
	= MYPATH + "관리자데이터.csv";
	
	public final static String SAVINGPRODUCT
	= MYPATH + "적금상품.csv";
	
	public final static String USERACCOUNTDATA
	= MYPATH + "고객예금계좌데이터.csv";
	
	public final static String USERDATA
	= MYPATH + "고객데이터.csv";
	
	public final static String USERFUNDDATA
	= MYPATH + "고객펀드계좌데이터.csv";
	
	public final static String USERSAVINGDATA
	= MYPATH + "고객적금계좌데이터.csv";
	
	public static final String INDIVIDUAL_ACCOUNT 
	= MYPATH + "고객별예금계좌/";
	
	
}
