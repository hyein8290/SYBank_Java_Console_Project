package com.group1.bankproject.deposit;

public class IndividualAccount{
	
	private String transTime;
	private int transMoney;
	private int Money;
	
	public String getTransTime() {
		return transTime;
	}
	
	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}
	
	public int getTransMoney() {
		return transMoney;
	}
	
	public void setTransMoney(int transMoney) {
		this.transMoney = transMoney;
	}
	
	public int getMoney() {
		return Money;
	}
	
	public void setMoney(int money) {
		Money = money;
	}
	
}