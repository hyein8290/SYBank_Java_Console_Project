package com.group1.bankproject.deposit;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Random;
import java.util.Scanner;

import com.group1.bankproject.MyPath;
import com.group1.bankproject.additionalWork.CurrentUser;

public class MakingAccount {

	private static Scanner scan;

	static {
		scan = new Scanner(System.in);
	}
	
	public int makeAccount() {
				
		System.out.println("계좌 개설을 선택하셨습니다.");
		System.out.println("===================================================");
		
		System.out.printf("%s님 본인 인증을 부탁드립니다.\r\n", CurrentUser.getName());

		verifyPassword();
		verifyJumin();
		
		System.out.println("본인 인증이 완료되었습니다.");
		
		selectPurpose();
		
		//TODO 뭐 동의해야 하는 지 알아 오기
 		System.out.println("무엇무엇 동의?");
		scan.nextLine();
		
		System.out.println("계좌 개설을 진행합니다.");
		System.out.println("계속 하시려면 1을, 취소하시려면 0을 눌러주세요.");
		
		while(true) {
			System.out.print("입력: ");
			
			int input = scan.nextInt();
			
			if(input == 1 || input == 0) {
				if(input == 1) {
					break;
				} else {
					System.out.println("계좌 개설을 취소하셨습니다.");
					System.out.println("이전 메뉴로 돌아갑니다.");
					return 0;
				}
			} else {
				System.out.println("1 또는 0만 입력해주세요.");
			}
		}

		String newAccount = generateAccont();
		
		try {
			
			BufferedWriter writer = new BufferedWriter(new FileWriter(MyPath.USERACCOUNTDATA, true));
				
			writer.write(String.format("%s,%s", CurrentUser.getNum(), newAccount));
			writer.newLine();
			writer.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("계좌 개설이 완료되었습니다.");
		System.out.println("계속 하시려면 엔터를 눌러주세요...");
		scan.nextLine();
		
		return 0;
		
	}

	private String generateAccont() {
		
		Random rnd = new Random();
		
		return "110-" + (rnd.nextInt(900) + 100) + "-" + (rnd.nextInt(9000) + 1000);
	}

	private void selectPurpose() {
		
		int input = 0;
		System.out.println("계좌 개설 목적을 선택해주세요.");
		System.out.println("1. 급여 계좌");
		System.out.println("2. 법인 계좌");
		System.out.println("3. 모임 계좌");
		System.out.println("4. 공과금 이체 계좌");
		System.out.println("5. 아르바이트 계좌");
		System.out.println("6. 그 외의 이유");
		
		try {
			
			System.out.print("입력: ");
			input = scan.nextInt();
			if(input < 1 || input > 6) {
				throw new Exception();
			}
			System.out.printf("%d번을 선택하셨습니다.\r\n", input);
			
		} catch (Exception e) {
			System.out.println("1~6의 숫자만 입력해주세요.");
		}

	}

	private void verifyJumin() {

		while(true) {
			
			String input = "";
			System.out.print("주민등록번호 입력(숫자만 입력):");
			input = scan.nextLine();
			
			if(!input.contains("-")) {
				
				if(input.equals(CurrentUser.getJumin().replace("-", ""))) {
					break;
				} else {
					System.out.println("잘못된 주민번호입니다. 다시 입력해주세요.");
				}
				
			} else {
				System.out.println("숫자만 입력해주세요.");
			}
			
		}
	}


	private void verifyPassword() {

		while(true) {
			
			String input = "";
			System.out.print("비밀번호 입력:");
			input = scan.nextLine();
			
			if(!input.equals(CurrentUser.getPassword())) {
				System.out.println("잘못된 비밀번호입니다. 다시 입력해주세요.");
			} else {
				break;
			}
		}

	}

	
}
