
package com.group1.bankproject;

public class Manager {

	   private static final String ID = "admin";
	   private static final String PASSWORD = "1111";

	   public static String getId() {
	      return ID;
	   }
	   public static String getPassword() {
	      return PASSWORD;
	   }
	   
	}