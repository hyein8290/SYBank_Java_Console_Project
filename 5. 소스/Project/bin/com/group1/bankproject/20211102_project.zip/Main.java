package com.group1.bankproject;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {
	
	static Scanner scan;
	static { scan = new Scanner(System.in); }
	
	public static void main(String[] args) throws IOException {
		
		boolean loop = true;
		
		while (loop) { 			
			System.out.println();
			System.out.println("███████╗██╗   ██╗██████╗  █████╗ ███╗   ██╗██╗  ██╗\r\n"
					+ "██╔════╝╚██╗ ██╔╝██╔══██╗██╔══██╗████╗  ██║██║ ██╔╝\r\n"
					+ "███████╗ ╚████╔╝ ██████╔╝███████║██╔██╗ ██║█████╔╝ \r\n"
					+ "╚════██║  ╚██╔╝  ██╔══██╗██╔══██║██║╚██╗██║██╔═██╗ \r\n"
					+ "███████║   ██║   ██████╔╝██║  ██║██║ ╚████║██║  ██╗\r\n"
					+ "╚══════╝   ╚═╝   ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝\r\n"
					+ "                                                   ");
			
			mainMenu();	
			Scanner scan = new Scanner(System.in);
			
			System.out.println();
			System.out.print("선택(숫자) : ");
			String sel = scan.nextLine();
		
			try {
				if (sel.equals("1")) {
					System.out.println();
					login.main(args);
				} else if (sel.equals("2")) {
					System.out.println("쌍용은행을 이용해주셔서 감사합니다.");
					System.exit(0);
				} else {
					loop = false;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		}//while 
		
		System.out.println();
		pause("1-2사이의 숫자를 입력해주세요.");
		Main.main(args);
		
	}//main
	
	private static void pause(String msg) {
		System.out.println(msg);
		System.out.println("계속 진행하시려면 엔터키를 누르세요.");
		scan.nextLine();
	}//pause + 디자인 변경 맟춰서 +-하기 
	
	private static void mainMenu() {
		
		System.out.println("====================================================");
		System.out.println("                      쌍용은행");
		System.out.println("----------------------------------------------------");
		System.out.println("                    1. 로그인 ");
		System.out.println("                    2. 종료 ");
		System.out.println("====================================================");
		
	}//mainMenu

}//Main.class