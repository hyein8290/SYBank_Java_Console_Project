package com.group1.bankproject;

public class UserAccountData {
	
	private int num;
	private String account;
	
	public UserAccountData() {
		
	}
	
	public UserAccountData(int num, String account) {
		this.num = num;
		this.account = account;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	
}
