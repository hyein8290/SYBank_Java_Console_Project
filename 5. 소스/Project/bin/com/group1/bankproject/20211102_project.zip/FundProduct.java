package com.group1.bankproject;

public class FundProduct {

	private int num;
	private String fundName;
	private double profitRate;
	private int period;
	private double fee;
	
	public FundProduct(int num, String fundName, double profitRate, int period, double fee) {

		this.num = num;
		this.fundName = fundName;
		this.profitRate = profitRate;
		this.period = period;
		this.fee = fee;
		
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getFundName() {
		return fundName;
	}

	public void setFundName(String fundName) {
		this.fundName = fundName;
	}

	public double getProfitRate() {
		return profitRate;
	}

	public void setProfitRate(double profitRate) {
		this.profitRate = profitRate;
	}

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		this.period = period;
	}

	public double getFee() {
		return fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

	@Override
	public String toString() {
		return String.format("FundProduct [num=%s, fundName=%s, profitRate=%s, period=%s, fee=%s]", num, fundName,
				profitRate, period, fee);
	}
	
	
}
