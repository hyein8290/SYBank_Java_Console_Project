package com.group1.bankproject;

public class UserData {
	
	private int num;
	private String id;
	private String password;
	private String name;
	private String address;
	private String jumin;
	private String tel;
	private int debt;
	
	public UserData() {
		
	}
	
	public UserData(int num, String id, String password, String name, String address, String jumin, String tel, int debt) {
		this.num = num;
		this.id = id;
		this.password = password;
		this.name = name;
		this.address = address;
		this.jumin = jumin;
		this.tel = tel;
		this.debt = debt;		
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getJumin() {
		return jumin;
	}


	public void setJumin(String jumin) {
		this.jumin = jumin;
	}


	public String getTel() {
		return tel;
	}


	public void setTel(String tel) {
		this.tel = tel;
	}


	public int getDebt() {
		return debt;
	}


	public void setDebt(int debt) {
		this.debt = debt;
	}


	public int getNum() {
		return num;
	}


	public void setNum(int num) {
		this.num = num;
	}


	@Override
	public String toString() {
		return String.format("UserData [num=%s, id=%s, password=%s, name=%s, address=%s, jumin=%s, tel=%s, debt=%s]",
				num, id, password, name, address, jumin, tel, debt);
	}
	
	
	
}
