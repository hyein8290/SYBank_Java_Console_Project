package com.group1.bankproject.bankproduct;

import java.util.Scanner;

import com.group1.bankproject.additionalWork.CurrentUser;



public class ProductMain {
	
	public static void main(String[] args) {
		
		CurrentUser.setNum(405);
		//print figlet

		Scanner scan = new Scanner(System.in);
		
		System.out.println("\n은행상품 메인화면을 시작합니다.\n");
		System.out.println("====================");
		System.out.println("    원하시는 상품/서비스를 선택해주세요.");
		System.out.println("====================");
		System.out.println("1. 적금");
		System.out.println("2. 대출");
		System.out.println("3. 펀드");
		System.out.println("4. 나의 가입상품");
		System.out.println("5. 뒤로가기");
		System.out.println("====================");
		System.out.print("선택(번호) : ");
		String sel = scan.nextLine();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();

		
		if (sel.equals("1")) {
		
			Saving.result();
		
		
		}else if (sel.equals("2")){

			
			LoanMain.main(null);
			
		}else if (sel.equals("3")){
			
			FundMain.main(null);
			
		}else if (sel.equals("4")){
			MyProduct.main(null);
			
		}else if (sel.equals("5")){

			
			
			
			
		}else {
			
			System.out.println("\n\n유효하지 않은 번호입니다. 다시 선택해주세요.\n\n");
			System.out.println();
			System.out.println();
			System.out.println();
			System.out.println();
			
			
			main(null);
			
		}

		
		
	}//main
	
	
	
	
	
}//class
