package com.group1.bankproject.bankproduct;

public class MyPath {

	public final static String myPath = "C:\\class\\java\\project\\data\\";
	
	public final static String FundProduct
	= myPath + "펀드상품.csv";

public final static String Manager
	= myPath + "관리자데이터.csv";

public final static String SavingProduct
	= myPath + "적금상품.csv";

public final static String UserAccountData
	= myPath + "고객예금계좌데이터.csv";

public final static String UserData
	= myPath + "고객데이터.csv";

public final static String UserFundData
	= myPath + "고객펀드계좌데이터.csv";

public final static String UserSavingData
	= myPath + "고객적금계좌데이터.csv";
	
	
}
