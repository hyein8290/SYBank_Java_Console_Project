package com.group1.bankproject;

import java.util.Scanner;

import com.group1.bankproject.additionalWork.additionalWorkMenu;
import com.group1.bankproject.bankproduct.ProductMain;
import com.group1.bankproject.deposit.Deposit;

public class userMain {
	
	private static Scanner scan;
	static { scan = new Scanner(System.in); }
	
	public static void main() {
		
		System.out.println();
		
		boolean loop = true;
		
		while (loop) {
			memberMenu();			
			Scanner scan = new Scanner(System.in);
			System.out.println();
			System.out.print("선택(숫자) : ");
			String sel = scan.nextLine();
			
			try {
				if (sel.equals("1")) {
					Deposit.selectMenu();
				} else if (sel.equals("2")) {
					ProductMain.main(null);
				} else if (sel.equals("3")) {
					additionalWorkMenu.main();
				} else if (sel.equals("4")) {
					System.out.println();
					System.out.println("이전 화면으로 이동합니다.");
					login.main(null);
				} else if (sel.equals("5")) {
					System.out.println("로그아웃 되었습니다.");
					login.main(null);
				} else if (sel.equals("6")) {
					System.out.println("쌍용은행을 이용해주셔서 감사합니다.");
					System.exit(0);
				} else {
					loop = false;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		}//while 
		
		System.out.println();
		System.out.println("1-5사이의 숫자를 입력해주세요.");
		userMain.main();
		
	}//main

	private static void memberMenu() {
	
		System.out.println("=====================");
		System.out.println("         회원");
		System.out.println("---------------------");
		System.out.println(" 1. 예금 ");
		System.out.println(" 2. 은행 상품 ");
		System.out.println(" 3. 추가 업무 ");
		System.out.println(" 4. 이전 화면 ");
		System.out.println(" 5. 로그아웃 ");
		System.out.println(" 6. 종료 ");
		System.out.println("=====================");
	
	}//memberMenu

}//Main.class
