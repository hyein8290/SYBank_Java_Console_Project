package com.group1.bankproject;

public class UserFundData {
	
	private int num;
	private String fundAccount;
	private int fundProductNum;
	
	public UserFundData(int num, String fundAccount, int fundProductNum) {
		this.num = num;
		this.fundAccount = fundAccount;
		this.fundProductNum = fundProductNum;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getFundAccount() {
		return fundAccount;
	}

	public void setFundAccount(String fundAccount) {
		this.fundAccount = fundAccount;
	}

	public int getFundProductNum() {
		return fundProductNum;
	}

	public void setFundProductNum(int fundProductNum) {
		this.fundProductNum = fundProductNum;
	}

	@Override
	public String toString() {
		return String.format("UserFundData [num=%s, fundAccount=%s, fundProductNum=%s]", num, fundAccount,
				fundProductNum);
	}
	
	

}
