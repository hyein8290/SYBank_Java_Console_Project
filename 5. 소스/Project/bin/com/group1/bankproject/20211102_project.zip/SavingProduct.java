package com.group1.bankproject;

public class SavingProduct {

	private int num;
	private String savingName;
	private double rate;
	private int period;
	
	public SavingProduct(int num, String savingName, int rate, int period) {
		
		this.num = num;
		this.savingName = savingName;
		this.rate = rate;
		this.period = period;
		
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getSavingName() {
		return savingName;
	}

	public void setSavingName(String savingName) {
		this.savingName = savingName;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(float rate) {
		this.rate = rate;
	}

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		this.period = period;
	}

	@Override
	public String toString() {
		return String.format("SavingProduct [num=%s, savingName=%s, rate=%s, period=%s]", num, savingName, rate,
				period);
	}
	
}
